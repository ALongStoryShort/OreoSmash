﻿

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Instantiate(ObjectToMake, transform.position, transform.rotation);
    }


