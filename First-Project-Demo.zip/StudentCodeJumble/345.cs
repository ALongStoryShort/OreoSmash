﻿
    //function can be run to create given object
    public void CreateObject()
    {
        Instantiate(ObjectToMake, transform.position, transform.rotation);
    }


